<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>IIEST College Management system</title>
  <?php include_once 'import_css.php'; ?>
</head>