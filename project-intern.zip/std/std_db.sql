-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2022 at 09:07 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `std_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `index_number` bigint(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `reg_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `index_number`, `name`, `gender`, `address`, `phone`, `email`, `image`, `reg_date`) VALUES
(14, 1, 'DHARAVATH NAGARAJU', 'Male', 'kolkata', '9381158667', 'dharavath@gmail.com', 'uploads/20220720084924.jpg', '2022-07-20');

-- --------------------------------------------------------

--
-- Table structure for table `classroom`
--

CREATE TABLE `classroom` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `student_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classroom`
--

INSERT INTO `classroom` (`id`, `name`, `student_count`) VALUES
(117, 'DSA', 100),
(118, 'graph algorithm', 90);

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `admission_fee` double(11,2) NOT NULL,
  `institute_fee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`id`, `name`, `admission_fee`, `institute_fee`) VALUES
(21, 'UG 1st Year', 7000.00, 25000),
(22, 'UG 2nd Year', 5000.00, 22000),
(23, 'UG 3rd Year', 3000.00, 27000),
(24, 'UG Final Year', 6000.00, 28000),
(25, '23', 5000.00, 23456);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `index_number` bigint(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `reg_date` date NOT NULL,
  `reg_year` year(4) NOT NULL,
  `reg_month` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `index_number`, `name`, `gender`, `address`, `phone`, `email`, `image`, `reg_date`, `reg_year`, `reg_month`) VALUES
(66, 21, 'santosh', 'Male', 'shibpur', '9786783454', 'santosh@gmail.com', 'uploads/20220718083954.jpeg', '2022-07-18', 2022, 'July'),
(67, 32, 'sai', 'Male', 'howrah', '4567896546', 'sai@gmail.com', 'uploads/20220720115857.jpeg', '2022-07-20', 2022, 'July'),
(68, 52, 'rahul choudari', 'Male', 'howrah', '7846578345', 'rahul@gmail.com', 'uploads/20220725081809.jpeg', '2022-07-25', 2022, 'July');

-- --------------------------------------------------------

--
-- Table structure for table `student_grade`
--

CREATE TABLE `student_grade` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `year` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_grade`
--

INSERT INTO `student_grade` (`id`, `student_id`, `grade_id`, `year`) VALUES
(299, 66, 21, 2022),
(300, 67, 22, 2022),
(301, 68, 21, 2022);

-- --------------------------------------------------------

--
-- Table structure for table `student_payment`
--

CREATE TABLE `student_payment` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `year` year(4) NOT NULL,
  `month` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `paid` double(11,2) NOT NULL,
  `_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_payment`
--

INSERT INTO `student_payment` (`id`, `student_id`, `year`, `month`, `date`, `paid`, `_status`) VALUES
(394, 53, 2022, 'July', '2022-07-01', 10000.00, 'Admission Fee'),
(395, 53, 2022, 'July', '2022-07-01', 0.00, 'Monthly Fee1'),
(396, 59, 2022, 'July', '2022-07-01', 499.00, 'Admission Fee'),
(397, 59, 2022, 'July', '2022-07-01', 1000.00, 'Monthly Fee1'),
(398, 60, 2022, 'July', '2022-07-08', 499.00, 'Admission Fee'),
(399, 60, 2022, 'July', '2022-07-08', 1000.00, 'Monthly Fee1'),
(400, 61, 2022, 'July', '2022-07-08', 499.00, 'Admission Fee'),
(401, 61, 2022, 'July', '2022-07-08', 1000.00, 'Monthly Fee1'),
(402, 62, 2022, 'July', '2022-07-08', 499.00, 'Admission Fee'),
(403, 62, 2022, 'July', '2022-07-08', 1000.00, 'Monthly Fee1'),
(404, 63, 2022, 'July', '2022-07-08', 499.00, 'Admission Fee'),
(405, 63, 2022, 'July', '2022-07-08', 1000.00, 'Monthly Fee1'),
(406, 65, 2022, 'July', '2022-07-08', 499.00, 'Admission Fee'),
(407, 65, 2022, 'July', '2022-07-08', 1000.00, 'Monthly Fee1'),
(408, 66, 2022, 'July', '2022-07-18', 7000.00, 'Admission Fee'),
(409, 66, 2022, 'July', '2022-07-18', 50000.00, 'Monthly Fee1'),
(410, 67, 2022, 'July', '2022-07-20', 5000.00, 'Admission Fee'),
(411, 67, 2022, 'July', '2022-07-20', 0.00, 'Monthly Fee1'),
(412, 68, 2022, 'July', '2022-07-25', 7000.00, 'Admission Fee'),
(413, 68, 2022, 'July', '2022-07-25', 50000.00, 'Monthly Fee1');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `sr_id` int(11) NOT NULL,
  `year` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_subject`
--

INSERT INTO `student_subject` (`id`, `student_id`, `sr_id`, `year`) VALUES
(261, 66, 23, 2022),
(262, 68, 23, 2022);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `name`) VALUES
(26, 'DBMS'),
(27, 'CN');

-- --------------------------------------------------------

--
-- Table structure for table `subject_routing`
--

CREATE TABLE `subject_routing` (
  `id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `fee` double(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject_routing`
--

INSERT INTO `subject_routing` (`id`, `grade_id`, `subject_id`, `teacher_id`, `fee`) VALUES
(22, 20, 25, 19, 1000.00),
(23, 21, 26, 19, 50000.00),
(24, 21, 27, 20, 40000.00);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `index_number` bigint(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `reg_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `index_number`, `name`, `gender`, `address`, `phone`, `email`, `image`, `reg_date`) VALUES
(19, 88, 'Prof.Indrajit Banerjee', 'Male', 'Kolkata', '7747383747', 'ibsir@gmail.com', 'uploads/2022071083959.jpg', '2022-07-01'),
(20, 89, 'prof.Arindam Biswas', 'Male', 'Howrah', '4878847878', 'absir@gmail.com', 'uploads/20220718083508.jpg', '2022-07-18');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_salary`
--

CREATE TABLE `teacher_salary` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `year` year(4) NOT NULL,
  `month` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `paid` double(11,2) NOT NULL,
  `_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_salary`
--

INSERT INTO `teacher_salary` (`id`, `teacher_id`, `year`, `month`, `date`, `paid`, `_status`) VALUES
(68, 17, 2022, 'July', '2022-07-01', 0.00, 'Monthly Salary'),
(69, 19, 2022, 'July', '2022-07-01', 0.00, 'Monthly Salary');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `type`) VALUES
(89, 'nagu250896@gmail.com', '$2y$10$f2sEbgzx2V9stIMwuE3rdezoiPciBJDGyztyBQmGTCPvK/JDn7pRa', 'Admin'),
(90, '510819034.dharavath@students.iiests.ac.in', '$2y$10$9U9vSDWinuP5IbCXZUdgZ.I/OQUfHfy2iOU1PXK1cwDTQ9kLCtIne', 'Student'),
(91, 'indraji@gmail.com', '$2y$10$cio71yH9W5kxPlCvBgIDqe74t8XAUDY4uiQ4GRGOoqlmCZ0kKVu6K', 'Teacher'),
(92, 'samanta@gmail.com', '$2y$10$VZWx03mpSmEotneDLSeTB.ZOHjktMKXWPg5E/tFBZlmrv8r5AIIU2', 'Student'),
(93, 'virat@gmail.com', '$2y$10$Zc6ncGvYvDnc80qOBa1AxewjwSh5L1gM/bv0l555v5mBKQg1cAuhC', 'Student'),
(94, 'arindam@gmail.com', '$2y$10$mZPAYs561xAcakMgdPm9R.FzV3rXpwh/3UnrhpAf3gXtVo21ziwHa', 'Teacher'),
(95, 'rajiv@gmail.com', '$2y$10$ADFS2YC0KsUuCTdtvM2wk.8UycRa0jo1gaWq.kuU9iLxpz3w6C7jW', 'Student'),
(96, 'fyt@gmail.com', '$2y$10$wICIn3iTLJO8DBDs9hu3guX/ta5toeGecQeQdVTL3WCrjA0Pe4d3O', 'Student'),
(97, 'raju@gmail.com', '$2y$10$ryGTR.r3wrUAGHSRXHhNAuLnKMsVcXQUH5XABAdg5EfBGqh7pxY1S', 'Student'),
(98, 'ibsir@gmail.com', '$2y$10$Yo0lWCItg0arWwFFTGgijuaGn29dzJEmL8OsnornNiWi02YPs3hxu', 'Teacher'),
(99, 'rajesh@gmail.com', '$2y$10$U5RC0KdlJpiOXrnBJpDwSeNAb7bp8yG32UyP.bWUw2z6u2b4pRK0m', 'Student'),
(100, 'rr@gmail.com', '$2y$10$vXACLmsbeSmsu2f78Z96kuDKnMQZe2dB2CdaUjUnmTq5u8/Ixmtne', 'Student'),
(101, 'jalender@gail.com', '$2y$10$4krqscNyyqRbc9vNsq1y6e1zUDItS2B8eXU/ES/sEHetZY2jnHBzC', 'Student'),
(102, 'eshwer@gmail.com', '$2y$10$mLfwlkpQ.RIMPwX6l2Sm2uA50SEpnBVJyJXLv958vzHSbBHw13Woi', 'Student'),
(103, 'fju@gmail.com', '$2y$10$0F8NcPmP5fxgop5YdkzGd.1uWrUXuE6PdJPJoCzWSM55e69vjX.jS', 'Student'),
(104, 'dgd@gmail.com', '$2y$10$4uXGaQhLsOrsdTwEKjtqBeiflOZ8VntFH4zmL1dWLuMKQzt.6PZCW', 'Student'),
(107, 'absir@gmail.com', '$2y$10$MIllaPbMPIwGdk4WdZPd0O..G5YK52wjSrYP1jBwuzOLPe89p45wG', 'Teacher'),
(108, 'santosh@gmail.com', '$2y$10$DHmH/LogKnl3PlK112mEDOXIs0Avr09.PtWOak0ug9JzKUt7sFzaO', 'Student'),
(109, 'dharavath@gmail.com', '$2y$10$h6H04vpv5B3Lhsx9smqGWOUZ6qXL.nKquqsGxVffVYxFZT2pP48eK', 'Admin'),
(110, 'sai@gmail.com', '$2y$10$TmP85c6V6AsAuAAs2U6VWO78DcFPSfj3RDHJ7LlKaS3r4NZVwP5DC', 'Student'),
(111, 'rahul@gmail.com', '$2y$10$SQeE/kc4phh3d3KZff3B5uGvv8aTCKNGGu5kK9BqqN0zeZCm/gBl2', 'Student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classroom`
--
ALTER TABLE `classroom`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_grade`
--
ALTER TABLE `student_grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_payment`
--
ALTER TABLE `student_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject_routing`
--
ALTER TABLE `subject_routing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_salary`
--
ALTER TABLE `teacher_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `classroom`
--
ALTER TABLE `classroom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `grade`
--
ALTER TABLE `grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `student_grade`
--
ALTER TABLE `student_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `student_payment`
--
ALTER TABLE `student_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=414;

--
-- AUTO_INCREMENT for table `student_subject`
--
ALTER TABLE `student_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=263;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `subject_routing`
--
ALTER TABLE `subject_routing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `teacher_salary`
--
ALTER TABLE `teacher_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
